B .header__main__list в li з іконкою корзини видалити блок .mini-cart-body, залишиться тільки іконка: 

<li class="header__main__list__item header__main__list__item-cart">
    <a href="./cart.html" class="mini-cart-dropdown-link">
        <span class="icon-shopping_cart_icon"></span>
        <div class="header__counter shopping_cart__counter">
            <span class="header__counter__value shopping_cart__counter__value">2</span>
        </div>
    </a>
</li>