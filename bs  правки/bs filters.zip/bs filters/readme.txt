1. Вкінці блоку .mini-cart-body додати <p class="mini-cart__empty-message">Немає товарів у кошику</p>
2. Якщо товарів в корзині немає: блоку .mini-cart-body додати клас .empty.


